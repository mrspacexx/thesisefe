package com.yourcompany.mamplus.firestore

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

data class UserPolicy(
    val isAdmin: Boolean = false,
    val blockUnknownSources: Boolean = true
)

object PolicyManager {
    private val db = FirebaseFirestore.getInstance()

    suspend fun getPolicyForUser(email: String): UserPolicy {
        return try {
            val doc = db.collection("users").document(email).get().await()
            if (doc.exists()) {
                doc.toObject(UserPolicy::class.java) ?: UserPolicy()
            } else {
                UserPolicy()
            }
        } catch (e: Exception) {
            Log.e("PolicyManager", "Error fetching policy: ${e.message}")
            UserPolicy()
        }
    }
}
