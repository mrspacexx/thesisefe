package com.yourcompany.mamplus

import android.os.Bundle
import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.lifecycle.lifecycleScope
import com.google.firebase.FirebaseApp
import com.yourcompany.mamplus.firestore.PolicyManager
import com.yourcompany.mamplus.ui.theme.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)

        setContent {
            var isLoggedIn by remember { mutableStateOf(false) }
            var userEmail by remember { mutableStateOf("") }
            var accessGranted by remember { mutableStateOf(false) }
            var accessReason by remember { mutableStateOf("") }

            if (!isLoggedIn) {
                LoginScreen(
                    onLoginSuccess = { email ->
                        isLoggedIn = true
                        userEmail = email

                        if (!email.endsWith("@elteranord.com")) {
                            accessGranted = false
                            accessReason = "Unauthorized domain"
                            return@LoginScreen
                        }

                        lifecycleScope.launch {
                            val policy = PolicyManager.getPolicyForUser(email)

                            // check
                            if (policy.blockUnknownSources) {
                                val pm = packageManager
                                val installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)

                                val nonPlayStoreApps = installedApps.filter { app ->
                                    val installer = pm.getInstallerPackageName(app.packageName)
                                    installer == null || installer != "com.android.vending"
                                }

                                if (nonPlayStoreApps.isNotEmpty()) {
                                    accessReason = "Unverified source detected: app not installed via Play Store"
                                    accessGranted = false
                                    return@launch
                                }
                            }

                            accessGranted = true
                        }
                    }
                )
            } else {
                if (accessGranted) {
                    SecurePortalScreen(userEmail)
                } else {
                    AccessBlockedScreen(reason = accessReason)
                }
            }
        }
    }

    // Optional utility if needed elsewhere
    private fun getInstalledPackages(): List<String> {
        val pm = packageManager
        val packages = pm.getInstalledApplications(0)
        return packages.map { it.packageName }
    }
}
