package com.yourcompany.mamplus

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.lifecycle.lifecycleScope
import com.yourcompany.mamplus.firestore.PolicyManager
import com.yourcompany.mamplus.ui.theme.*
import com.yourcompany.mamplus.util.AuthManager
import com.yourcompany.mamplus.util.RootDetector
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            var isLoggedIn by remember { mutableStateOf(false) }
            var userEmail by remember { mutableStateOf("") }
            var accessGranted by remember { mutableStateOf(false) }
            var accessReason by remember { mutableStateOf("") }

            if (!isLoggedIn) {
                LoginScreen(
                    onLoginSuccess = { email ->
                        isLoggedIn = true
                        userEmail = email

                        // Restrict to corporate domain
                        if (!email.endsWith("@elteranord.com")) {
                            accessGranted = false
                            accessReason = "Unauthorized domain"
                            return@LoginScreen
                        }

                        //  Async loading of policy
                        lifecycleScope.launch {
                            val policy = PolicyManager.getPolicyForUser(email)

                            if (policy.rootCheckEnabled && RootDetector.isDeviceRooted()) {
                                if (policy.blockIfRooted) {
                                    accessGranted = false
                                    accessReason = "Device is rooted"
                                    return@launch
                                }
                            }


                            // I will add more checks here later (OS version, encryption, etc.)
                            }

                            accessGranted = true
                    }
                )
            } else {
                if (accessGranted) {
                    SecurePortalScreen(userEmail)
                } else {
                    AccessBlockedScreen(reason = accessReason)
                }
            }
        }
    }
}
