package com.yourcompany.mamplus.util

import android.app.Activity
import android.content.Intent
import androidx.activity.result.ActivityResultLauncher
import com.google.android.gms.auth.api.signin.*
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.*

object AuthManager {
    fun getSignInClient(activity: Activity): GoogleSignInClient {
        val options = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken("509062837384-oj5haob7ih7idf5d1b5vgk5v5p3eobsq.apps.googleusercontent.com") // ✅ Your real Web Client ID
            .requestEmail()
            .build()

        return GoogleSignIn.getClient(activity, options)
    }

    fun handleSignInResult(
        task: Task<GoogleSignInAccount>,
        onSuccess: (String) -> Unit,
        onFailure: (String) -> Unit
    ) {
        try {
            val account = task.result
            val email = account?.email ?: "unknown"
            onSuccess(email)
        } catch (e: Exception) {
            onFailure(e.message ?: "Login failed")
        }
    }
}
