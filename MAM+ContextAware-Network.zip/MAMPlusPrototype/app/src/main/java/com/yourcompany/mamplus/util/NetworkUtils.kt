package com.yourcompany.mamplus.util

import java.net.InetAddress
import java.net.NetworkInterface
import java.util.*

object NetworkUtils {

    fun getLocalIpAddress(): String {
        try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            for (intf in interfaces) {
                val addrs = Collections.list(intf.inetAddresses)
                for (addr in addrs) {
                    if (!addr.isLoopbackAddress && addr is InetAddress) {
                        val ip = addr.hostAddress ?: continue
                        if (!ip.contains(":")) return ip
                    }
                }
            }
        } catch (ex: Exception) {
        }
        return "0.0.0.0"
    }

    fun isIpInRange(ip: String, cidr: String): Boolean {
        try {
            val (network, prefix) = cidr.split("/")
            val networkAddr = ipToInt(network)
            val ipAddr = ipToInt(ip)
            val mask = (-1 shl (32 - prefix.toInt()))
            return (ipAddr and mask) == (networkAddr and mask)
        } catch (e: Exception) {
            return false
        }
    }

    private fun ipToInt(ipStr: String): Int {
        val parts = ipStr.split(".").map { it.toInt() }
        return (parts[0] shl 24) or (parts[1] shl 16) or (parts[2] shl 8) or parts[3]
    }
}
