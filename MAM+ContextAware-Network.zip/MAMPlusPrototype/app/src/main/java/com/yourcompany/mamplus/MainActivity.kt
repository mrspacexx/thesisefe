package com.yourcompany.mamplus

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.lifecycle.lifecycleScope
import com.yourcompany.mamplus.firestore.PolicyManager
import com.yourcompany.mamplus.ui.theme.*
import com.yourcompany.mamplus.util.AuthManager
import com.yourcompany.mamplus.util.NetworkUtils
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            var isLoggedIn by remember { mutableStateOf(false) }
            var userEmail by remember { mutableStateOf("") }
            var accessGranted by remember { mutableStateOf(false) }
            var accessReason by remember { mutableStateOf("") }

            if (!isLoggedIn) {
                LoginScreen(
                    onLoginSuccess = { email ->
                        isLoggedIn = true
                        userEmail = email

                        // Only allow @elteranord.com domain
                        if (!email.endsWith("@elteranord.com")) {
                            accessGranted = false
                            accessReason = "Unauthorized domain"
                            return@LoginScreen
                        }

                        lifecycleScope.launch {
                            val policy = PolicyManager.getPolicyForUser(email)

                            //  IP RESTRICTION CHECK
                            if (policy.ipRestrictionEnabled) {
                                val currentIp = NetworkUtils.getLocalIpAddress()
                                val trustedRange = policy.trustedIpRange

                                if (!NetworkUtils.isIpInRange(currentIp, trustedRange)) {
                                    accessGranted = false
                                    accessReason = "Untrusted network"
                                    return@launch
                                }
                            }

                            //  Passed all checks
                            accessGranted = true
                        }
                    }
                )
            } else {
                if (accessGranted) {
                    SecurePortalScreen(userEmail)
                } else {
                    AccessBlockedScreen(reason = accessReason)
                }
            }
        }
    }
}

