package com.yourcompany.mamplus.util

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import com.google.android.gms.location.*

@SuppressLint("MissingPermission")
fun getCurrentLocation(context: Context, callback: (Double, Double) -> Unit) {
    val fusedClient = LocationServices.getFusedLocationProviderClient(context)

    val request = LocationRequest.create().apply {
        priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        interval = 1000
        numUpdates = 1
    }

    fusedClient.requestLocationUpdates(request, object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            val location: Location? = result.lastLocation
            if (location != null) {
                callback(location.latitude, location.longitude)
            } else {
                callback(0.0, 0.0)
            }
        }
    }, null)
}

fun isTrustedLocation(
    currentLat: Double,
    currentLon: Double,
    allowedLat: Double,
    allowedLon: Double,
    radius: Double = 0.1
): Boolean {
    return (currentLat in (allowedLat - radius)..(allowedLat + radius)) &&
            (currentLon in (allowedLon - radius)..(allowedLon + radius))
}
