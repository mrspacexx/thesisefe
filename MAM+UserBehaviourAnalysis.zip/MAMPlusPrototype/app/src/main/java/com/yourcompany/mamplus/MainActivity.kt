package com.yourcompany.mamplus

import android.os.Bundle
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.lifecycle.lifecycleScope
import com.google.firebase.FirebaseApp
import com.yourcompany.mamplus.firestore.PolicyManager
import com.yourcompany.mamplus.ui.theme.*
import kotlinx.coroutines.launch
import java.util.*

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)

        setContent {
            var isLoggedIn by remember { mutableStateOf(false) }
            var userEmail by remember { mutableStateOf("") }
            var accessGranted by remember { mutableStateOf(false) }
            var accessReason by remember { mutableStateOf("") }

            if (!isLoggedIn) {
                LoginScreen(
                    onLoginSuccess = { email ->
                        isLoggedIn = true
                        userEmail = email

                        if (!email.endsWith("@elteranord.com")) {
                            accessGranted = false
                            accessReason = "Unauthorized domain"
                            return@LoginScreen
                        }

                        lifecycleScope.launch {
                            val policy = PolicyManager.getPolicyForUser(email)

                            if (policy.behaviorAnalysisEnabled) {
                                val currentTime = System.currentTimeMillis()
                                val currentHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                                val lastTime = policy.lastLoginTimestamp
                                val lastModel = policy.lastKnownDeviceModel
                                val lastHour = policy.lastLoginHour

                                val timeDiff = currentTime - lastTime
                                val currentModel = Build.MODEL

                                var riskScore = 0

                                if (lastTime > 0 && timeDiff < 2 * 60 * 1000) {
                                    riskScore += 40 // Too frequent login
                                }

                                if (lastModel.isNotEmpty() && lastModel != currentModel) {
                                    riskScore += 40 // Device model changed
                                }

                                if (currentHour in 0..5) {
                                    riskScore += 20 // Login at night
                                }

                                if (riskScore >= 60) {
                                    accessGranted = false
                                    accessReason = "Abnormal behavior detected (risk score: $riskScore)"
                                    return@launch
                                }

                                // Passed behavior check – update login data
                                PolicyManager.updateLoginBehavior(email, currentTime, currentModel, currentHour)
                            }

                            accessGranted = true
                        }
                    }
                )
            } else {
                if (accessGranted) {
                    SecurePortalScreen(userEmail)
                } else {
                    AccessBlockedScreen(reason = accessReason)
                }
            }
        }
    }
}
