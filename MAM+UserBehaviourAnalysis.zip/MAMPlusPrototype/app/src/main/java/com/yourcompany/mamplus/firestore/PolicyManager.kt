package com.yourcompany.mamplus.firestore

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

data class UserPolicy(
    val isAdmin: Boolean = false,
    val behaviorAnalysisEnabled: Boolean = true,
    val lastLoginTimestamp: Long = 0L,
    val lastKnownDeviceModel: String = "",
    val lastLoginHour: Int = -1
)

object PolicyManager {
    private val db = FirebaseFirestore.getInstance()

    suspend fun getPolicyForUser(email: String): UserPolicy {
        return try {
            val doc = db.collection("users").document(email).get().await()
            if (doc.exists()) {
                doc.toObject(UserPolicy::class.java) ?: UserPolicy()
            } else {
                UserPolicy()
            }
        } catch (e: Exception) {
            Log.e("PolicyManager", "Error fetching policy: ${e.message}")
            UserPolicy()
        }
    }

    suspend fun updateLoginBehavior(email: String, timestamp: Long, model: String, hour: Int) {
        try {
            val updates = mapOf(
                "lastLoginTimestamp" to timestamp,
                "lastKnownDeviceModel" to model,
                "lastLoginHour" to hour
            )
            db.collection("users").document(email).update(updates).await()
        } catch (e: Exception) {
            Log.e("PolicyManager", "Failed to update login behavior: ${e.message}")
        }
    }
}
