package com.yourcompany.mamplus.util

import android.content.Context
import android.net.wifi.WifiManager
import java.net.InetAddress

object IpUtils {
    fun getLocalIpAddress(context: Context): String {
        val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val ipInt = wifiManager.connectionInfo.ipAddress
        return InetAddress.getByAddress(
            byteArrayOf(
                (ipInt and 0xff).toByte(),
                (ipInt shr 8 and 0xff).toByte(),
                (ipInt shr 16 and 0xff).toByte(),
                (ipInt shr 24 and 0xff).toByte()
            )
        ).hostAddress ?: "0.0.0.0"
    }

    fun isIpInRange(ip: String, cidr: String): Boolean {
        try {
            val parts = cidr.split("/")
            val subnet = InetAddress.getByName(parts[0]).address
            val maskLength = parts[1].toInt()
            val mask = -0x1 shl (32 - maskLength)

            val ipInt = InetAddress.getByName(ip).address.fold(0) { acc, byte -> (acc shl 8) or (byte.toInt() and 0xFF) }
            val subnetInt = subnet.fold(0) { acc, byte -> (acc shl 8) or (byte.toInt() and 0xFF) }

            return ipInt and mask == subnetInt and mask
        } catch (e: Exception) {
            return false
        }
    }
}
