package com.yourcompany.mamplus

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.core.app.ActivityCompat
import androidx.lifecycle.lifecycleScope
import com.google.firebase.FirebaseApp
import com.yourcompany.mamplus.firestore.PolicyManager
import com.yourcompany.mamplus.ui.theme.*
import com.yourcompany.mamplus.util.getCurrentLocation
import com.yourcompany.mamplus.util.isTrustedLocation
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)

        setContent {
            var isLoggedIn by remember { mutableStateOf(false) }
            var userEmail by remember { mutableStateOf("") }
            var accessGranted by remember { mutableStateOf(false) }
            var accessReason by remember { mutableStateOf("") }

            val locationPermissionLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.RequestPermission()
            ) { granted ->
                if (!granted) {
                    accessGranted = false
                    accessReason = "Location permission denied"
                }
            }

            if (!isLoggedIn) {
                LoginScreen(
                    onLoginSuccess = { email ->
                        isLoggedIn = true
                        userEmail = email

                        if (!email.endsWith("@elteranord.com")) {
                            accessGranted = false
                            accessReason = "Unauthorized domain"
                            return@LoginScreen
                        }

                        if (ActivityCompat.checkSelfPermission(
                                this,
                                Manifest.permission.ACCESS_FINE_LOCATION
                            ) != PackageManager.PERMISSION_GRANTED
                        ) {
                            locationPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                            return@LoginScreen
                        }

                        lifecycleScope.launch {
                            val policy = PolicyManager.getPolicyForUser(email)

                            if (policy.locationRestrictionEnabled) {
                                getCurrentLocation(this@MainActivity) { lat, lon ->
                                    val trusted = isTrustedLocation(
                                        currentLat = lat,
                                        currentLon = lon,
                                        allowedLat = policy.allowedLatitude,
                                        allowedLon = policy.allowedLongitude
                                    )

                                    if (!trusted) {
                                        accessReason = "Untrusted location"
                                        accessGranted = false
                                    } else {
                                        accessGranted = true
                                    }
                                }
                            } else {
                                accessGranted = true
                            }
                        }
                    }
                )
            } else {
                if (accessGranted) {
                    SecurePortalScreen(userEmail)
                } else {
                    AccessBlockedScreen(reason = accessReason)
                }
            }
        }
    }
}


