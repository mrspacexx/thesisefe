package com.yourcompany.mamplus.firestore

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.toObject
import kotlinx.coroutines.tasks.await

data class UserPolicy(
    val isAdmin: Boolean = false,
    val locationRestrictionEnabled: Boolean = true,
    val allowedLatitude: Double = 56.936607,
    val allowedLongitude: Double = 24.1568
)



object PolicyManager {
    private val db = FirebaseFirestore.getInstance()

    suspend fun getPolicyForUser(email: String): UserPolicy {
        return try {
            val doc = db.collection("users").document(email).get().await()
            if (doc.exists()) {
                doc.toObject(UserPolicy::class.java) ?: UserPolicy()
            } else {
                Log.w("PolicyManager", "Policy not found for $email. Using default.")
                UserPolicy()
            }
        } catch (e: Exception) {
            Log.e("PolicyManager", "Error fetching policy: ${e.message}")
            UserPolicy()
        }
    }
}
