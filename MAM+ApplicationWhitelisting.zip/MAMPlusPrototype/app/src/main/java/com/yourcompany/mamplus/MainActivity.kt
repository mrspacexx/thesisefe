package com.yourcompany.mamplus

import android.os.Bundle
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.lifecycle.lifecycleScope
import com.google.firebase.FirebaseApp
import com.yourcompany.mamplus.firestore.PolicyManager
import com.yourcompany.mamplus.ui.theme.*
import kotlinx.coroutines.launch
import java.util.*

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)

        setContent {
            var isLoggedIn by remember { mutableStateOf(false) }
            var userEmail by remember { mutableStateOf("") }
            var accessGranted by remember { mutableStateOf(false) }
            var accessReason by remember { mutableStateOf("") }

            if (!isLoggedIn) {
                LoginScreen(
                    onLoginSuccess = { email ->
                        isLoggedIn = true
                        userEmail = email

                        if (!email.endsWith("@elteranord.com")) {
                            accessGranted = false
                            accessReason = "Unauthorized domain"
                            return@LoginScreen
                        }

                        lifecycleScope.launch {
                            val policy = PolicyManager.getPolicyForUser(email)

                            //   Application Whitelisting
                            if (policy.appWhitelistingEnabled) {
                                val installed = getInstalledPackages()
                                val allowed = policy.allowedPackages

                                val unauthorizedApps = installed.filterNot { pkg -> allowed.contains(pkg) }

                                if (unauthorizedApps.isNotEmpty()) {
                                    accessReason = "Unauthorized applications detected"
                                    accessGranted = false
                                    return@launch
                                }
                            }

                            accessGranted = true
                        }
                    }
                )
            } else {
                if (accessGranted) {
                    SecurePortalScreen(userEmail)
                } else {
                    AccessBlockedScreen(reason = accessReason)
                }
            }
        }
    }

    // Gets list of installed application package names
    private fun getInstalledPackages(): List<String> {
        val pm = packageManager
        val packages = pm.getInstalledApplications(0)
        return packages.map { it.packageName }
    }
}
