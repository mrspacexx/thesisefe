package com.yourcompany.mamplus.util

import android.app.KeyguardManager
import android.content.Context
import android.os.Build
import android.os.UserManager
import android.util.Log
import com.yourcompany.mamplus.firestore.UserPolicy

object TrustScoreEvaluator {

    fun evaluate(context: Context, policy: UserPolicy): Int {
        var score = 100

        // OS version check
        if (policy.osVersionCheckEnabled && Build.VERSION.SDK_INT < 29) {
            score -= 40
            Log.d("TrustScore", "OS version too old: -40")
        }

        // Encryption check
        if (policy.encryptionCheckEnabled && !isEncryptionEnabled(context)) {
            score -= 40
            Log.d("TrustScore", "Encryption not enabled: -40")
        }

        // Screen lock check
        if (policy.screenLockCheckEnabled && !isScreenLockEnabled(context)) {
            score -= 20
            Log.d("TrustScore", "Screen lock not set: -20")
        }

        Log.d("TrustScore", "Final trust score = $score")
        return score
    }

    private fun isEncryptionEnabled(context: Context): Boolean {
        val userManager = context.getSystemService(Context.USER_SERVICE) as UserManager
        return userManager.isUserUnlocked
    }

    private fun isScreenLockEnabled(context: Context): Boolean {
        val keyguardManager = context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        return keyguardManager.isKeyguardSecure
    }
}

