package com.yourcompany.mamplus

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.lifecycle.lifecycleScope
import com.yourcompany.mamplus.firestore.PolicyManager
import com.yourcompany.mamplus.ui.theme.*
import com.yourcompany.mamplus.util.AuthManager
import com.yourcompany.mamplus.util.TrustScoreEvaluator
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            var isLoggedIn by remember { mutableStateOf(false) }
            var userEmail by remember { mutableStateOf("") }
            var accessGranted by remember { mutableStateOf(false) }
            var accessReason by remember { mutableStateOf("") }

            if (!isLoggedIn) {
                LoginScreen(
                    onLoginSuccess = { email ->
                        isLoggedIn = true
                        userEmail = email

                        // Restrict domain
                        if (!email.endsWith("@elteranord.com")) {
                            accessGranted = false
                            accessReason = "Unauthorized domain"
                            return@LoginScreen
                        }

                        // 🔄 Fetch policy and evaluate trust score
                        lifecycleScope.launch {
                            val policy = PolicyManager.getPolicyForUser(email)

                            // ✅ Evaluate trust score (skip root)
                            val trustScore = TrustScoreEvaluator.evaluate(applicationContext, policy)

                            if (trustScore < policy.minTrustScore) {
                                accessGranted = false
                                accessReason = "Trust score too low: $trustScore"
                                return@launch
                            }

                            accessGranted = true
                        }
                    }
                )
            } else {
                if (accessGranted) {
                    SecurePortalScreen(userEmail)
                } else {
                    AccessBlockedScreen(reason = accessReason)
                }
            }
        }
    }
}
